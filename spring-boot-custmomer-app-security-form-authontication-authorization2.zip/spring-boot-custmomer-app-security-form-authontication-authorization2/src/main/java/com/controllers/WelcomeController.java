package com.controllers;

import io.swagger.annotations.ApiOperation;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {

	public WelcomeController() {
	System.out.println("WelcomeController created....");
	}
	
	
	@ApiOperation("returns model message as Welcome To Spring Web MVC at Syntel in welcome.jsp ")
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public ModelAndView welcome(){
     System.out.println("In WelcomeController  welcome method");
	return new ModelAndView("welcome", "message", "Welcome To Spring Web MVC at Atos Syntel");
	}
	
	
	
	
	
	
}
