package com.controllers;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {

	
	
	public HelloController() {
	System.out.println("Hello Controller created....");
	}
	
	
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"),
		      @ApiResponse(code = 404, message = "Invalid url"),@ApiResponse(code = 500, message = "Internal Server Error") })
	@ApiOperation("returns hello.jsp page")
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public String hello(){
     System.out.println("In HelloCntroller  hello method");
	return "hello";
	}
	
	
	
	
}
